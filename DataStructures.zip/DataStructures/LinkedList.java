package DataStructures;
import Project.*;
public class LinkedList {
private GuestNode first;
public LinkedList() {
		first = null;
	}

public boolean isEmpty() {
		if (first == null) {
			return true;
		} else
			return false;
	}
public GuestNode getFirst() {
	return first;
}
public void display() {
		GuestNode current = first;
		while (current != null) {
			System.out.print(current.guest+ " ");
			current = current.next;
		}
	}
public void insertAtFront(Guest d) {
		GuestNode p = new GuestNode(d);
		if (first == null) {
			first = p;
		} else {
			p.next = first;
			first = p;
		}
	}
public void insertAtBack(Guest d) {
		GuestNode p = new GuestNode(d);
		if (first == null) {
			first = p;
		} else {
			GuestNode current = first;
			while (current.next != null) {
				current = current.next;
			}
			current.next = p;
		}
	}
public void insertAtPosition(Guest d, int position) {
		GuestNode p = new GuestNode(d);
		if (first == null) {
			first = p;
		} else {
			GuestNode current = first;
			for (int i = 1; i < position - 1; i++) {
				current = current.next;

				if (current.next == null) {
					break;
				}
			}
			p.next = current.next;
			current.next = p;
		}
	}
public Guest deleteFromFront() {
		if (first == null) {
			return null;
		} else {
			Guest a=first.guest;
			first = first.next;
			return a;
		}
	}
public Guest deleteFromBack() {
		if (first == null) {
			return null;
		} else {
			GuestNode current = first;
			while (current.next.next != null) {
				current = current.next;
			}
			Guest g = current.next.guest;
			current.next = null;
			return g;
		}
	}
public Guest deleteFromIndex(int index) {
		if (first == null) {
			return null;
		} else {
			GuestNode current = first;
			GuestNode prev=current;
			for (int i=0; i<index; i++) {
				if(current==null) {
					return null;
				}
				prev=current;
				current = current.next;
			}
			Guest g = current.guest;
			prev.next = current.next;
			return g;
		}
	}

public boolean searchValue(Guest a) {
		if (first == null) {
			return false;
		} else {
			GuestNode current = first;
			while (current != null) {
				if (current.guest == a) {
					return true;
				}
				current = current.next;
			}
			return false;
		}
	}
}

