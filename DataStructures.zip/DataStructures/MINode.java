package DataStructures;

import Project.MenuItem;

public class MINode {
	MenuItem item;
	MINode next;
	
	MINode(){
		item=null;
		next=null;
	}
	MINode(MenuItem item){
		this.item=item;
		next=null;
	}
}
