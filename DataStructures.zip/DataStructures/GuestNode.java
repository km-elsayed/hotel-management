package DataStructures;

import Project.Guest;

public class GuestNode {
	Guest guest;
	GuestNode next;
	GuestNode(){
		guest=null;
		next=null;
	}
	GuestNode(Guest g){
		guest=g;
		next=null;
	}
}
