package DataStructures;

import Project.MenuItem;

public class MIQueue extends MILinkedList{
	public MIQueue(){
		super();
	}
	public void enqueue(MenuItem d) {
		insertAtBack(d);
	}
	public MenuItem dequeue() {
		return deleteFromFront();
	}
	public MenuItem peek() {
		return getFirst().item;
	}
	
}
