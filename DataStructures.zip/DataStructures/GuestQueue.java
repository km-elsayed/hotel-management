package DataStructures;

import Project.Guest;

public class GuestQueue {
	GuestNode first;
	public GuestQueue(){
		first=null;
	}
	public boolean isEmpty() {
		return first==null;
	}
	public void enqueue(Guest g) {
		GuestNode p = new GuestNode(g);
		if (first == null) {
			first = p;
		} else {
			GuestNode current = first;
			while (current.next != null) {
				current = current.next;
			}
			current.next = p;
		}
	}
	public Guest dequeue() {
		if (isEmpty()) {
			return null;
		} else {
			Guest a=first.guest;
			first = first.next;
			return a;
		}
	}
	public Guest peek() {
		return first.guest;
	}
	public void display() {
		GuestQueue tmp = new GuestQueue();
		while(!isEmpty()) {
			Guest g = dequeue();
			tmp.enqueue(g);
			System.out.println(g.getName()+" ");
		}
		System.out.println();
		while(!tmp.isEmpty()) {
			enqueue(tmp.dequeue());
		}
	}
}
