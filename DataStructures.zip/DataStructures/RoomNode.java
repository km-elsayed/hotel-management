package DataStructures;

import Project.Room;

public class RoomNode {
	Room room;
	RoomNode next;
	int key;
	
	RoomNode(){
		room=null;
		next=null;
		key=0;
	}
	RoomNode(Room r){
		room=r;
		key=0;
	}
	RoomNode(Room r, int k){
		room=r;
		key=k;
	}
}
