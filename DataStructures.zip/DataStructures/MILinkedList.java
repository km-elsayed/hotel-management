package DataStructures;

import Project.MenuItem;

public class MILinkedList {
	private MINode first;
	public MILinkedList() {
			first = null;
		}

	public boolean isEmpty() {
			if (first == null) {
				return true;
			} else
				return false;
		}
	public MINode getFirst() {
		return first;
	}
	public void display() {
		System.out.println("Menu:");
		int i=1;
		MINode current = first;
		while (current != null) {
			System.out.println(i+". " + current.item.getName()+ ": $"+current.item.getPrice());
			i++;
			current = current.next;
		}
	}
	public void insertAtFront(MenuItem d) {
			MINode p = new MINode(d);
			if (isEmpty()) {
				first = p;
			} else {
				p.next = first;
				first = p;
			}
		}
	public void insertAtBack(MenuItem d) {
			MINode p = new MINode(d);
			if (isEmpty()) {
				first = p;
			} else {
				MINode current = first;
				while (current.next != null) {
					current = current.next;
				}
				current.next = p;
			}
		}
	public void insertAtPosition(MenuItem d, int position) {
			MINode p = new MINode(d);
			if (first == null) {
				first = p;
			} else {
				MINode current = first;
				for (int i = 1; i < position - 1; i++) {
					current = current.next;

					if (current.next == null) {
						break;
					}
				}
				p.next = current.next;
				current.next = p;
			}
		}
	public MenuItem deleteFromFront() {
			if (first == null) {
				return null;
			} else {
				MenuItem a=first.item;
				first = first.next;
				return a;
			}
		}
	public boolean deleteFromBack() {
			if (first == null) {
				return false;
			} else {
				MINode current = first;
				while (current.next.next != null) {
					current = current.next;
				}
				current.next = null;
				return true;
			}
		}
	public boolean deleteFromIndex(int n) {
			if (first == null) {
				return false;
			}
			if(n==0) {
				first=first.next;
				return true;
			}
			MINode current = first;
			MINode prev=current;
			for(int i=0;i<n;i++) {
				if(current==null) {
					return false;
				}
				prev=current;
				current=current.next;
			}
			prev.next=current.next;
			return true;
		}
	public boolean deleteElement(MenuItem c) {
			if (first == null) {
				return false;
			} else {
				if (first.item == c) {

					first = first.next;
					return true;
				} else {
					MINode current = first;
					while (current.next != null) {
						if (current.next.item == c) {

					      current.next = current.next.next;
					     return true;
						}
						current = current.next;
					}
					return false;
				}
			}
		}
	public MenuItem searchPosition(int pos) {
		if (isEmpty()) {
			return null;
		} else {
			MINode current = first;
			while (current != null && pos>0) {
				pos--;
				if(pos==0) {
					return current.item;
				}
				current = current.next;
			}
			return null;
		}
	}
	public MenuItem search(MenuItem m) {
		MINode current=first;
		while(current!=null) {
			if(current.item.getName() == m.getName()) {
				return current.item;
			}
			current=current.next;
		}
		return null;
	}
	public MenuItem search(String name) {
			if (isEmpty()) {
				return null;
			} else {
				MINode current = first;
				while (current != null) {
					if (current.item.getName() == name) {
						return current.item;
					}
					current = current.next;
				}
				return null;
			}
		}
}
