package DataStructures;

import Project.*;

public class RoomPQ {
	RoomNode first;
	public RoomPQ(){
		first=null;
	}
	boolean isEmpty() {
		return first==null;
	}
	public void enqueue(Room r) {
		RoomNode node = new RoomNode(r);
		if (isEmpty()) {
			first = node;
		} else {
			RoomNode current = first;
			while (current.next != null) {
				current = current.next;
			}
			node.key=current.key+1;
			current.next = node;
		}
	}
	public void enqueue(Room r, int k) {
	    RoomNode p = new RoomNode(r, k);
	    if (first == null || k < first.key) {
	        p.next = first;
	        first = p;
	    } else {
	        RoomNode current = first;
	        while (current.next != null && current.next.key < k) {
	            current = current.next;
	        }
	        p.next = current.next;
	        current.next = p;
	    }
	}

	public Room dequeue(){
		if(!isEmpty()) {
			Room r = first.room;
			first=first.next;
			return r;
		}
		return null;
	}
	public void display() {
		RoomPQ tmp = new RoomPQ();
		while(!isEmpty()) {
			int key=first.key;
			Room x = dequeue();
			tmp.enqueue(x,key);
			System.out.println(x.getRoomNbr()+" ");
		}
		while(!tmp.isEmpty()) {
			int key=tmp.first.key;
			enqueue(tmp.dequeue(),key);
		}
	}
	public Room search(Room r) {
		RoomNode current=first;
		while(current!=null) {
			if(current.room.getRoomNbr()==r.getRoomNbr()) {
				return current.room;
			}
			current=current.next;
		}
		return null;
	}
}
