package DataStructures;
import Project.*;
public class GuestStack extends LinkedList{
	public GuestStack() {
		super();
	}
	public boolean isEmpty() {
		return super.isEmpty();
	}
	public void push(Guest a) {
		insertAtFront(a);
	}
	public Guest pop() {
		return deleteFromFront();
	}
	public Guest peek() {
		Guest a= deleteFromFront();
		push(a);
		return a;
	}
	
	public void display() {
		if(isEmpty()) {
			System.out.println("No record to display");
			return;
		}
		GuestStack temp = new GuestStack();
		while (!isEmpty()) {
			Guest a = pop();
			a.display();
			temp.push(a);
		}
		while (!temp.isEmpty()) {
			push(temp.pop());
		}
		System.out.println();
	}
	
}
