package Project;

public class Employee {
	public static int idCounter=1000;
	public int id;
	public String name;
	public int salary;
	public int bonus;
	public Hotel hotel;
	public Manager manager;
	
	Employee(){
		id=idCounter++;
		name="";
		salary=0;
		bonus=0;
		hotel=null;
		
	}
	Employee(String name,int salary,Hotel hotel){
		id=idCounter++;
		this.name=name;
		this.salary=salary;
		this.hotel=hotel;
		bonus=0;
	}

	public void display() {
		System.out.println("Name: "+name+"\nID: "+id+"\nSalary: "+salary);
	}
	public int calcSalary() {
		return salary+bonus;
	}
//------------------------------------------------------------------

	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel=hotel;
	}
	public void setManager(Manager m) {
		manager=m;
	}
}
