package Project;
import java.util.ArrayList;
public class Guest {
	private static int idCounter = 2000; 
	private int id;
	private String name;
	private Room room;
	private ArrayList<Order> bill;
	private Hotel hotel;


	public Guest() {
		this.id = idCounter++;
		this.name = "Guest" + id;
		this.room = null;
		this.bill = new ArrayList<Order>();
		this.hotel=null;
	}

	public Guest(String name,Hotel hotel) {
		id=idCounter++;
		this.name=name;
		this.room = null;
		this.hotel=hotel;
		this.bill = new ArrayList<Order>();
	}
	public Guest(String name) {
		id=idCounter++;
		this.name=name;
		this.room = null;
		this.hotel=null;
		this.bill = new ArrayList<Order>();
	}
	public void order(MenuItem item, int quantity) {
		if(item!=null) {
			hotel.getOrderList().enqueue(item);
			Order order = new Order(item.getName(),item.getPrice(),quantity);
			bill.add(order);
			System.out.println("Placed order successfully.");
		}
		else {
			System.out.println("Item not available");
		}
	}
	public void order(String name, int quantity) {
		MenuItem item=hotel.getMenu().search(name);
		if(item!=null) {
			for(int i=0;i<quantity;i++) {
				hotel.getOrderList().enqueue(item);
			}
			System.out.println("Placed order successfully.");
		}
		else {
			System.out.println("Item not available");
		}
	}


	public void requestCleanup() {
		if(room==null) {
			System.out.println(name+" not checked in.");
			return;
		}
		if(hotel.getToClean().search(room)!=null) {
			System.out.println("Room already in Queue");
			return;
		}
		int floor = room.getRoomNbr()/100;
		hotel.getToClean().enqueue(room, floor);
		System.out.println(name + " requested room cleanup.");
	}

	
	public int calculateBill() {
	  
	    int totalBill = 0;
	    for (int i = 0; i < bill.size(); i++) {
	        totalBill += bill.get(i).getPrice()*bill.get(i).getQuantity();
	    }
	    return totalBill;
	}
	public void printReciept() {
	    for (int i = 0; i < bill.size(); i++) {
	    	System.out.println(bill.get(i).getQuantity()+"x "+bill.get(i).getName()+": $"+bill.get(i).getPrice()*bill.get(i).getQuantity());
	    }
	    System.out.println("Total: \t$"+calculateBill());
	}


	
	public void display() {
		System.out.println("Guest:");
		System.out.println("ID: " + id);
		System.out.println("Name: " + name);
		if (room != null) {
		    System.out.println("Room: " + room.getRoomNbr());
		} else {
		    System.out.println("Room: Not assigned");
		}

		System.out.println("Bill: \n" + calculateBill());
	}
//------------------------------------------------------------------

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public static int getIdCounter() {
		return idCounter;
	}

	public static void setIdCounter(int idCounter) {
		Guest.idCounter = idCounter;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setBill(ArrayList<Order> bill) {
		this.bill = bill;
	}

	public ArrayList<Order> getBill() {
		return bill;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel h) {
		hotel=h;
	}
	
}