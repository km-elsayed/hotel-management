package Project;
import java.util.*;
public class Manager extends Employee{
	public ArrayList<Employee> employees;
	public int numManaged;
	Scanner sc = new Scanner(System.in);
	public Manager(){
		super();
		numManaged=0;
		employees=new ArrayList<>();
	}
	public Manager(String name,int salary,Hotel hotel) {
		super(name,salary,hotel);
		numManaged=0;
		employees=new ArrayList<>();
	}
	public void addEmployee(Employee e) {
		if(e instanceof Manager) {
			return;
		}
		employees.add(e);
		e.setManager(this);
		numManaged++;
	}
	public void removeEmployee(Employee e) {
		numManaged--;
		employees.remove(e);
	}
	public Employee searchEmployeeID(int id) {
		for(int i=0;i<employees.size();i++) {
			if(employees.get(i).getId()==id) 
				return employees.get(i);
		}
		return null;
	}
	public Employee searchEmployee(String name) {
		for(int i=0;i<employees.size();i++) {
			if(employees.get(i).getName().equals(name)) 
				return employees.get(i);
		}
		return null;
	}
	public boolean setBonus(int id, int bonus) {
		Employee e = searchEmployeeID(id);
		if(e!=null) {
			e.bonus+=bonus;
			return true;
		}
		return false;
	}
	public void setBonusAll(int bonus) {
		for(int i=0;i<employees.size();i++) {
			employees.get(i).bonus+=bonus;
		}
	}
	public boolean promote(String name) {
		Employee e = searchEmployee(name);
		if(e!=null) {
			if(e instanceof Manager) {
				System.out.println("Already promoted");
				return false;
			}
			else {
				e= new Manager(e.name,e.salary+1000,e.hotel);
				removeEmployee(e);
				return true;
			}
		}
		else {
			System.out.println("Employee not found");
			return false;
		}
	}
	public int calcSalary() {
		return salary+bonus;
	}
	public void displayEmployees() {
		for(int i=0;i<employees.size();i++) {
			System.out.println(employees.get(i).name);
		}
	}
}
