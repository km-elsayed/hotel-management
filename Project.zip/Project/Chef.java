package Project;
public class Chef extends Employee{
	public Manager manager;
	Chef(){
		super();
		manager=null;
	}
	Chef(String name,int salary,Hotel hotel){
		super(name,salary,hotel);
		manager=null;
	}
	public void prepareOrder() {
		if(hotel.getOrderList().isEmpty()) {
			System.out.println("No orders to prepare");
			return;
		}
		MenuItem m = hotel.getOrderList().dequeue();
		System.out.println(name+" prepared "+m.getName());
	}
	
}
