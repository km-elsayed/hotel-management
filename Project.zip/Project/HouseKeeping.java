package Project;
public class HouseKeeping extends Employee{
	Manager manager;
	public HouseKeeping(){
		super();
		manager=null;
		
	}
	public HouseKeeping(String name,int salary,Hotel hotel){
		super(name,salary,hotel);
		manager=null;
	}
	public void clean() {
		Room r = hotel.getToClean().dequeue();
		if(r==null) {
			System.out.println("No rooms to clean");
			return;
		}
		System.out.println(name+" cleaned Room "+r.getRoomNbr());
	}
}
