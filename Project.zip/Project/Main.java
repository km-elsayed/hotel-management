package Project;
import java.util.*;
public class Main {
	public static void main(String[] args) {
		//initialise hotel and attributes
		Scanner sc = new Scanner(System.in);
		Hotel hotel= new Hotel(3,5);
		Manager m = new Manager("As3ad",1500,hotel);
		Chef b = new Chef("Bilal",600,hotel);
		HouseKeeping k= new HouseKeeping("Ramy",500,hotel);
		Employee emp[]= {m,b,k};
		hotel.setEmployees(emp);
		m.addEmployee(b);
		m.addEmployee(k);
		hotel.AddMenuItem("pasta",20);
		hotel.AddMenuItem("pizza",15);
		hotel.AddMenuItem("orange juice",3);
		Guest g= new Guest("Karen");
		Guest g1= new Guest("Leen",hotel);
		Guest g2= new Guest("Adam",hotel);
		Guest g3= new Guest("Julia",hotel);
		Guest g4= new Guest("Dani",hotel);
		Guest arr[] = {g,g1,g2,g3,g4};
		hotel.queueGuests(arr);
		hotel.getToClean().display();
		int op=-1;
		System.out.println("Welcome to our Hotel! :D");
		while(op!=0) {
		System.out.println("Operations: \n1. Reception\n2.Staff\n---Enter '0' to exit---");
		 op=sc.nextInt();
		while(op!=1 && op!=2 && op!=0) {
			System.out.println("Invalid option, please try again: ");
			op=sc.nextInt();
		}
		if(op==1) {
			System.out.println("How many guests would you like to help? ");
			int num_g=sc.nextInt();
			while(num_g>0) {
				if(hotel.getReceptionQueue().isEmpty()) {
					System.out.println("Queue is empty");
					break;
				}
				hotel.next();
				num_g--;
			}
		}
		else if(op==2) {
			System.out.println("Pick one:\n1.Manager operation\n2.Employee Operation\n3.Display Records\n---Enter '0' to exit---");
			int c = sc.nextInt();
			while(c!=1 && c!=2 && c!=3 && c!=0) {
				System.out.println("Please pick one of available options: ");
				c=sc.nextInt();
			}
			if(c==1) {
				System.out.println("Manage Hotel:\n1.Hire Employee\n2.Fire Employee\n3.Promote Employee\n4.Set Bonus\n5.Calculate Employee Salaries\n---Enter '0' to exit---");
				int c2 = sc.nextInt();
				while(c2<0 && c2>6) {
					System.out.println("Please pick one of available options: ");
					c2=sc.nextInt();
				}
				switch(c2) {
				case 1:
					System.out.print("Enter employee name: ");
					String name = sc.next();
					System.out.print("Enter salary: ");
					int salary=sc.nextInt();
					System.out.println("Employee is a 1.Chef or 2. HouseKeeping? \n---Enter '0' to exit---");
					int j= sc.nextInt();
					while(j!=1 && j!=2 && j!=0) {
						System.out.println("Please enter either 1 or 2 \n---Enter '0' to exit---");
						j=sc.nextInt();
					}
					if(j==1) {
						Chef e = new Chef (name,salary,hotel);
						hotel.hire(e);
						m.addEmployee(e);
					}
					else if(j==2){
						HouseKeeping e = new HouseKeeping (name,salary,hotel);
						hotel.hire(e);
						m.addEmployee(e);
					}
					break;
				case 2:
					System.out.println("Employees Managed:");
					m.displayEmployees();
					System.out.println("Enter name of employee to be fired: ");
					String name1=sc.next();
					Employee e1 =m.searchEmployee(name1);
					if(e1!=null) {
						hotel.fire(e1.id);
					}
					else {
						System.out.println("Employee not under your management");
					}
					break;
				case 3:
					System.out.println("Enter name of employee to be promoted: ");
					String n1=sc.next();
					m.promote(n1);
					break;
				case 4:
					System.out.println("Would you like to set a bonus for \n1.All employees or \n2.A certain employee?");
					int c3=sc.nextInt();
					while(c3<0 && c3>2) {
						System.out.println("Please pick one of available options: \n---Enter '0' to exit---");
						c3=sc.nextInt();
					}
					System.out.println("How much would you like to set? ");
					int bonus=sc.nextInt();
					if(c3==1) {
						m.setBonusAll(bonus);
					}
					else if(c3==2) {
						System.out.println("Enter name of employee: ");
						String n2=sc.next();
						m.setBonus(m.searchEmployee(n2).id, bonus);
					}
					break;
				case 5:
					hotel.displaySalaries();
					default:
						break;
				}
			}
			else if(c==2) {
				System.out.println("1.Clean\n2.Prepare Order---Enter '0' to exit---");
				int c2=sc.nextInt();
				while(c2!=1 && c2!=2 && c2!=0) {
					System.out.println("Please enter one of available options: ");
					c2=sc.nextInt();
				}
				if(c2==1) {
					if(hotel.getHouseKeeping()!=null) {
					hotel.getHouseKeeping().clean();
					}
					else {
						System.out.println("No Housekeeping available to clean");
					}
				}
				else if(c2==2) {
					if(hotel.getChef()!=null) {
						hotel.getChef().prepareOrder();
						}
						else {
							System.out.println("No Chefs available to prepare order");
						}
				}
			}else if(c==3) {
				System.out.println("What room would you like to display the records for?");
				int num=sc.nextInt();
				while(hotel.searchRoom(num)==null) {
					System.out.println("Room not found, please try again");
					num=sc.nextInt();
				}
				hotel.searchRoom(num).displayRecord();
			}
		}
		else {
			System.out.println("Thank you, come again soon!");
		}
	}
	}

}
