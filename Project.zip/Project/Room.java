package Project;
import DataStructures.*;
public class Room {
    private int roomNbr;
    private Hotel hotel;
    private Guest[] guests;
    int capacity;
    int current;
    private GuestStack guestRecord;

    public Room(int roomNbr,int capacity,Hotel hotel) {
    	this.hotel=hotel;
        this.roomNbr = roomNbr;
        current=0;
        this.capacity=capacity;
        this.guests = new Guest[capacity];
        this.guestRecord = new GuestStack();
    }
    public boolean isEmpty() {
    	return current==0;
    }
    public boolean isAvailable() {
    	return current<capacity;
    }
    public boolean checkIn(Guest g) {
    	for(int i=0;i<guests.length;i++) {
    		if(guests[i]==g) {
    			System.out.println(g.getName()+" already checked in");
    			return false;
    		}
    	}
    	if(!isAvailable()) {
    		System.out.println("Cannot check in "+g.getName()+" ,room full.");
    		return false;
    	}
    	else {
    		guests[current]=g;
    		current++;
    		g.setRoom(this);
    		guestRecord.push(g);
    		hotel.getGuests().add(g);
    		System.out.println("Checked in successfully to Room "+roomNbr);
    		return true;
    	}
    }
    public void checkOut() {
    	for(int i=0;i<current;i++) {
    		hotel.getGuests().remove(guests[i]);
    	}
    	current=0;
    	guests=new Guest[capacity];
    }
    public void display() {
        System.out.println("Room Information:");
        System.out.println("Room Number: " + roomNbr);
        System.out.print("Availability: ");
        if (isAvailable()) {
            System.out.println("Available");
        } else {
            System.out.println("Full Capacity");
        }

        if (!isEmpty()) {
            System.out.println("Guests in Room:");
            for (int i = 0; i < guests.length; i++) {
                System.out.println("- " + guests[i].getName());
            }

        } else {
            System.out.println("No guests in the room.");
        }
    }
    public void displayRecord() {
    	guestRecord.display();
    }
//------------------------------------------------------------------
    public int getRoomNbr() {
        return roomNbr;
    }

    public void setRoomNbr(int roomNbr) {
        this.roomNbr = roomNbr;
    }
    
    public Guest[] getGuests() {
        return guests;
    }

    public void setGuests(Guest[] guests) {
        this.guests = guests;
    }
    public GuestStack getGuestRecord() {
        return guestRecord;
    }
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getCurrent() {
		return current;
	}
	public void setCurrent(int current) {
		this.current = current;
	}
	public void setGuestRecord(GuestStack guestRecord) {
		this.guestRecord = guestRecord;
	}

}