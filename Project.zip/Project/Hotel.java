package Project;
import DataStructures.*;
import java.util.*;
public class Hotel {
	private Room[][] Rooms;
	private Employee[] employees;
	private ArrayList<Guest> guests = new ArrayList<>();
	private MILinkedList menu;
	private MIQueue orderList;
	private RoomPQ toClean;
	private GuestQueue receptionQueue;
	
	Scanner sc = new Scanner(System.in);
	
	Hotel(int floors,int rooms){
		employees = new Employee[0];
		menu=new MILinkedList();
		orderList=new MIQueue();
		toClean = new RoomPQ();
		receptionQueue = new GuestQueue();
		Rooms=new Room[floors][rooms];
		for(int i=1;i<=floors;i++) {
			for(int j=1;j<=rooms;j++) {
				Rooms[i-1][j-1]=new Room((i*100+j),i,this);
			}
		}
	}
	public void queueGuests(Guest g[]) {
		for(int i=0;i<g.length;i++) {
			g[i].setHotel(this);
			receptionQueue.enqueue(g[i]);
		}
	}
	public void displayAvailable() { //ex: room no 302
		int floor = Rooms.length;
		int room = Rooms[0].length;
		for(int i=0;i<floor;i++) {
			for(int j=0;j<room;j++) {
				if(Rooms[i][j].isAvailable())
					System.out.print(Rooms[i][j].getRoomNbr()+" ");
			}
			System.out.println();
		}
	}
	
	public void AddMenuItem(String name, int price) {
		MenuItem item= new MenuItem(price,name);
		menu.insertAtBack(item);
	}
	public boolean checkIn(int num, Guest g) {
		return Rooms[num/100-1][num%100-1].checkIn(g);
	}
	public void checkOut(Guest g) {
		if(g.getRoom()!=null) {
			toClean.enqueue(g.getRoom(),0);
			g.getRoom().checkOut();
		}
		else {
			System.out.println("Guest not checked in");
		}
	}
	public void spaceLeft(int num) {
		int c=Rooms[num/100-1][num%100-1].capacity-Rooms[num/100-1][num%100-1].current;
		if(c==0) {
			System.out.println("Room Full");
		}
		else {
			System.out.println("Space for "+c+" more guests left");
		}
	}
	public void next() {

		System.out.println();
		Guest g= receptionQueue.dequeue();
		if(g==null) {
			System.out.println("Queue empty");
			System.out.println();
			return;
		}
		System.out.println("Hello "+g.getName()+"!");
		int choice=-1;
		while(choice!=0) {
		if(searchGuest(g.getName())!=null) {
			System.out.println("You are checked into room "+ g.getRoom().getRoomNbr());
			System.out.println("Would you like to: \n1.Order\n2.Request Cleanup\n3.Check out\n---Press '0'  to exit---");
			 choice=sc.nextInt();
			 while(choice >3 && choice<0) {
				 System.out.println("Please pick one of the available options: ");
				 choice=sc.nextInt();
			 }
			if(choice==1) {
				menu.display();
				System.out.print("What would you like to order?: ");
				int n=sc.nextInt();
				while(menu.searchPosition(n)==null) {
					System.out.println("Please enter number of item you'd like to order:");
					n=sc.nextInt();
				}
				System.out.print("How many?: ");
				int q =sc.nextInt();
				g.order(menu.searchPosition(n), q);
			}
			else if(choice==2) {
				g.requestCleanup();
			}
			else if(choice==3) {
				g.printReciept();
				checkOut(g);
				System.out.println("Thank you for staying with us");
				return;
			}
			else {
				break;
			}
		}
		else {
		System.out.println("Would you like to: \n1.Check in\n2.Check menu\n---Press '0' else to exit---");
		choice=sc.nextInt();
		while(choice>2 && choice<0) {
			System.out.println("Please pick one of the available options: ");
			choice=sc.nextInt();
		}
		if(choice==1) {
			System.out.println("Available Rooms:");
			displayAvailable();
			System.out.println("What room would you like to check in to?");
			int num=sc.nextInt();
			while(searchRoom(num)==null) {
				System.out.println("Room not found, please try again: ");
				num=sc.nextInt();
			}
			g.setHotel(this);
			while(!checkIn(num,g)) {
				System.out.println("Please pick another room: ");
				num=sc.nextInt();
			}
		}
		else if(choice==2) {
			menu.display();
		}
		else {
			break;
		}
		}
	}
	}
	public void hire(Employee e) {
		if(searchEmployee(e.id)!=null) {
			System.out.println("Employee already hired");
			return;
		}
			int numManaged=employees.length+1;
			Employee[] arr = new Employee[numManaged];
			arr[0]=e;
			for(int i=0;i<employees.length;i++) {
				arr[i+1]=employees[i];
			}
			employees=new Employee[numManaged];
			for(int i=0;i<numManaged;i++) {
				employees[i]=arr[i];
			}
			System.out.println(e.name+" hired successfully");
	}
	public void fire(int id) {
		Employee e= searchEmployee(id);
		if(e.manager!=null) {
			e.manager.removeEmployee(e);
		}
		int index=-1;
		Employee[] arr = new Employee[employees.length-1];
		for(int i=0;i<employees.length;i++) {
			if(employees[i].getId()!=id) {
				arr[i]=employees[i];
			}
			else {
				index=i;
				break;
			}
		}
		if(index==-1) {
			System.out.println("Employee not found");
			return;
		}
		System.out.println(employees[index].name+" fired successfully");
		for(int i=index+1;i<employees.length;i++) {
			arr[i-1]=employees[i];
		}
		employees=new Employee[arr.length];
		for(int i=0;i<employees.length;i++) {
			employees[i]=arr[i];
		}
	}
	public boolean setManager(Employee m, Employee e) {
		if(m!=null && e!=null && m instanceof Manager) {
			if(e instanceof Chef) {
				((Chef)e).setManager((Manager)m);
				return true;
			}
			else if(e instanceof HouseKeeping) {
				((HouseKeeping)e).setManager((Manager)m);
				return true;
			}
			else {
				System.out.println("Cannot set manager to manager");
				return false;
			}
		}
		else {
			return false;
		}
	}
	public void calcSalaries() {
		for(int i=0;i<employees.length;i++) {
			System.out.println(employees[i].name+" Salary: $"+employees[i].calcSalary());
		}
	}
	public void displayEmployees() {
		for(int i=0;i<employees.length;i++) {
			System.out.println("Employee "+(i+1)+": ");
			System.out.println("Name: " + employees[i].name+"\nSalary: "+employees[i].salary);
			if( employees[i] instanceof Manager) {
				System.out.println("Job: Manager\nNumbers Managed: "+((Manager)employees[i]).numManaged);
			}
			else {
				System.out.println("Job: Employee");
			}
			System.out.println();
		}
	}
	public void displaySalaries() {
		for(int i=0;i<employees.length;i++) {
			System.out.println("Employee "+(i+1)+": ");
			System.out.println("Name: " + employees[i].name+"\nSalary: "+employees[i].calcSalary());
			System.out.println();
		}
	}
	public HouseKeeping getHouseKeeping() {
		for(int i=0;i<employees.length;i++) {
			if(employees[i] instanceof HouseKeeping) {
				return (HouseKeeping)employees[i];
			}
		}
		return null;
	}
	public Chef getChef() {
		for(int i=0;i<employees.length;i++) {
			if(employees[i] instanceof Chef) {
				return (Chef)employees[i];
			}
		}
		return null;
	}
//-------------------------------------------------------------------------------------------------------------------
	public Room searchRoom(int num) {
		int maxFloor=Rooms.length;
		int maxRoom=Rooms[0].length;
		if(num/100>maxFloor || num/100<1 || num%100>maxRoom || num%100<1) {
			return null;
		}
		if(num/100<=maxFloor && num%100<=maxRoom) {
			return Rooms[num/100-1][num%100-1];
		}
		else {
			return null;
		}
	}
	public Guest searchGuest(String name) {
		for(int i=0;i<guests.size();i++) {
			if(guests.get(i).getName()==name) {
				return guests.get(i);
			}
		}
		return null;
	}
	public Employee searchEmployee(int id) {
		for(int i=0;i<employees.length;i++) {
			if(employees[i].getId()==id) 
				return employees[i];
		}
		return null;
	}
	

	public Room[][] getRooms() {
		return Rooms;
	}

	public void setRooms(Room[][] rooms) {
		Rooms = rooms;
	}

	public Employee[] getEmployees() {
		return employees;
	}

	public void setEmployees(Employee[] employees) {
		this.employees = employees;
	}

	public MILinkedList getMenu() {
		return menu;
	}

	public void setMenu(MILinkedList menu) {
		this.menu = menu;
	}

	public MIQueue getOrderList() {
		return orderList;
	}

	public void setOrderList(MIQueue orderList) {
		this.orderList = orderList;
	}

	public RoomPQ getToClean() {
		return toClean;
	}

	public void setToClean(RoomPQ toClean) {
		this.toClean = toClean;
	}

	public GuestQueue getReceptionQueue() {
		return receptionQueue;
	}

	public void setReceptionQueue(GuestQueue receptionQueue) {
		this.receptionQueue = receptionQueue;
	}
	public ArrayList<Guest> getGuests() {
		return guests;
	}
	public void setGuests(ArrayList<Guest> guests) {
		this.guests = guests;
	}
	public Scanner getSc() {
		return sc;
	}
	public void setSc(Scanner sc) {
		this.sc = sc;
	}
	
}
